"""
finopt.solver — 2D airfoil polar solvers behind one interface.

Deliverable D0 of the fin-optimizer roadmap.

Two solvers implement the SAME interface so everything downstream (the
objective in D2, the optimizer in D4) is written once and never has to
know which solver produced the numbers:

    XfoilSolver  — drives a real XFOIL binary via subprocess (run on your
                   laptop / CAEN where xfoil exists).
    MockSolver   — a cheap analytic stand-in (thin-airfoil + quadratic drag)
                   so the pipeline can be developed and unit-tested anywhere
                   XFOIL is NOT installed. NOT physics — a placeholder.

Swap is a one-line change:
    solver = XfoilSolver("xfoil")      # real
    solver = MockSolver()              # dev / CI

Both return a `Polar`. Both accept geometry either as a NACA 4-digit code
or as an (N,2) array of (x, y) coordinates — the coordinate path is what
makes the pipeline family-agnostic (Eppler, CH, UIUC .dat, anything).
"""

from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
import warnings
from dataclasses import dataclass, field

import numpy as np


# --------------------------------------------------------------------------
# Result type
# --------------------------------------------------------------------------
@dataclass
class Polar:
    """A solved polar: aligned arrays of angle of attack and coefficients.

    Only CONVERGED points are stored. `alpha` is in degrees.
    """
    alpha: np.ndarray          # deg
    cl: np.ndarray
    cd: np.ndarray
    cm: np.ndarray
    reynolds: float
    source: str                # which solver / geometry produced this
    n_requested: int = 0       # how many alphas were asked for
    meta: dict = field(default_factory=dict)

    # --- convenience accessors ------------------------------------------
    @property
    def n_converged(self) -> int:
        return len(self.alpha)

    @property
    def convergence_rate(self) -> float:
        return self.n_converged / self.n_requested if self.n_requested else 0.0

    def cl_at(self, a_deg: float) -> float:
        """Linear-interpolated CL at a given alpha (deg). NaN if out of range."""
        return self._interp(self.cl, a_deg)

    def cd_at(self, a_deg: float) -> float:
        return self._interp(self.cd, a_deg)

    def cm_at(self, a_deg: float) -> float:
        return self._interp(self.cm, a_deg)

    def _interp(self, y: np.ndarray, a_deg: float) -> float:
        if self.n_converged == 0:
            return float("nan")
        if a_deg < self.alpha.min() or a_deg > self.alpha.max():
            return float("nan")
        # np.interp needs ascending x; alpha is sorted on construction
        return float(np.interp(a_deg, self.alpha, y))

    def cl_slope_per_deg(self, lo: float = -3.0, hi: float = 3.0) -> float:
        """Lift-curve slope (per deg) from a least-squares fit in [lo, hi].

        Sanity check: thin-airfoil theory gives ~0.1097 /deg (2*pi per rad).
        """
        m = (self.alpha >= lo) & (self.alpha <= hi)
        if m.sum() < 2:
            return float("nan")
        A = np.polyfit(self.alpha[m], self.cl[m], 1)
        return float(A[0])

    def __repr__(self) -> str:
        return (f"Polar({self.source}, Re={self.reynolds:.2e}, "
                f"{self.n_converged}/{self.n_requested} converged)")


# --------------------------------------------------------------------------
# Base interface
# --------------------------------------------------------------------------
class BaseSolver:
    """Common interface. Subclasses implement `run_coords`.

    `run_naca` has a default that generates coordinates with a 4-digit
    generator and calls `run_coords`, so a solver only MUST implement the
    coordinate path. (XfoilSolver overrides run_naca to use XFOIL's own
    built-in NACA command, which is the cleanest D0 check.)
    """

    def run_coords(self, coords: np.ndarray, reynolds: float,
                   alphas: np.ndarray, name: str = "coords") -> Polar:
        raise NotImplementedError

    def run_naca(self, code: str, reynolds: float,
                 alphas: np.ndarray) -> Polar:
        from finopt.geometry import naca4_coords
        coords = naca4_coords(code)
        return self.run_coords(coords, reynolds, alphas, name=f"NACA{code}")


# --------------------------------------------------------------------------
# Real XFOIL subprocess wrapper
# --------------------------------------------------------------------------
class XfoilSolver(BaseSolver):
    """Drive a real XFOIL binary through its stdin command interface.

    Robustness choices (XFOIL is notoriously flaky):
      * Alpha sweep runs OUTWARD FROM 0 (0->max, then re-init, 0->min) so
        each point continues from a converged neighbour — far more robust
        than a single ASEQ through stall.
      * Per-run wall-clock `timeout`; a hung XFOIL is killed, not waited on.
      * Only converged points (those XFOIL writes to its accumulated polar
        file) are returned; non-converged alphas are silently dropped and
        counted in Polar.meta['dropped'].
      * ITER limit is configurable.

    Parameters
    ----------
    xfoil_path : path to the xfoil executable (default "xfoil", i.e. on PATH).
    iters      : XFOIL viscous iteration cap per alpha.
    ncrit      : e^n transition parameter (9 = "clean wind tunnel"; LOWER
                 (~4-7) for the rougher, higher-turbulence flow a roadgoing
                 fin actually sees. This single knob matters a LOT at the
                 low Reynolds numbers of a 366 mm-chord fin — flag it in
                 any cross-airfoil comparison.)
    timeout    : seconds before a single xfoil invocation is killed.
    """

    def __init__(self, xfoil_path: str = "xfoil", iters: int = 200,
                 ncrit: float = 9.0, timeout: float = 60.0,
                 n_panel: int = 240):
        self.xfoil_path = xfoil_path
        self.iters = iters
        self.ncrit = ncrit
        self.timeout = timeout
        self.n_panel = n_panel
        resolved = shutil.which(xfoil_path) or (
            xfoil_path if os.path.isfile(xfoil_path) else None)
        self.available = resolved is not None
        self._resolved = resolved

    # -- public: NACA via XFOIL's own generator (cleanest D0 check) -------
    def run_naca(self, code: str, reynolds: float,
                 alphas: np.ndarray) -> Polar:
        geom_cmds = [f"NACA {code}", "PANE"]
        return self._run(geom_cmds, reynolds, alphas, source=f"XFOIL NACA{code}")

    # -- public: arbitrary coordinates (family-agnostic path) ------------
    def run_coords(self, coords: np.ndarray, reynolds: float,
                   alphas: np.ndarray, name: str = "coords") -> Polar:
        coords = np.asarray(coords, float)
        datfile = tempfile.NamedTemporaryFile(
            mode="w", suffix=".dat", delete=False, dir=_tmpdir())
        try:
            datfile.write(f"{name}\n")
            for x, y in coords:
                datfile.write(f"{x:.6f} {y:.6f}\n")
            datfile.close()
            geom_cmds = [f"LOAD {datfile.name}", "PANE"]
            return self._run(geom_cmds, reynolds, alphas,
                             source=f"XFOIL {name}")
        finally:
            _quiet_remove(datfile.name)

    # -- engine ----------------------------------------------------------
    def _run(self, geom_cmds, reynolds, alphas, source) -> Polar:
        """Solve a polar by invoking XFOIL ONCE PER ALPHA.

        Why one process per alpha instead of a single multi-alpha session:
        on some XFOIL builds (observed on 6.99 under WSL) a multi-ALFA stdin
        stream silently stops executing after the first angle — XFOIL solves
        alpha[0], then ignores every later command until QUIT, and PACC writes
        nothing. One fresh process per alpha sidesteps that entirely: each run
        is a known-good minimal session, and results are read from stdout (the
        one output that's reliable across builds). Cost is ~0.1-0.3 s/alpha of
        process spawn, which is negligible for airfoil polars.

        Geometry is set up once per call via `geom_cmds` (NACA or LOAD+PANE),
        replayed in each per-alpha session.
        """
        if not self.available:
            raise FileNotFoundError(
                f"XFOIL binary '{self.xfoil_path}' not found on PATH. "
                f"Install XFOIL or use MockSolver() for pipeline development.")

        alphas = np.asarray(alphas, float)
        a_list, cl_list, cd_list, cm_list = [], [], [], []

        for a in alphas:
            res = self._solve_one(geom_cmds, reynolds, float(a))
            if res is not None:
                cl, cd, cm = res
                a_list.append(float(a)); cl_list.append(cl)
                cd_list.append(cd); cm_list.append(cm)

        alpha_c = np.array(a_list)
        cl_c = np.array(cl_list)
        cd_c = np.array(cd_list)
        cm_c = np.array(cm_list)

        order = np.argsort(alpha_c) if len(alpha_c) else slice(None)
        polar = Polar(
            alpha=alpha_c[order] if len(alpha_c) else alpha_c,
            cl=cl_c[order] if len(cl_c) else cl_c,
            cd=cd_c[order] if len(cd_c) else cd_c,
            cm=cm_c[order] if len(cm_c) else cm_c,
            reynolds=reynolds, source=source, n_requested=len(alphas),
            meta={"dropped": len(alphas) - len(alpha_c),
                  "ncrit": self.ncrit, "iters": self.iters,
                  "mode": "per-alpha"})
        if polar.n_converged == 0:
            warnings.warn(f"XFOIL returned NO converged points for {source}. "
                          f"Check the binary, Reynolds number, and alpha range.")
        return polar

    def _solve_one(self, geom_cmds, reynolds, alpha):
        """Run one headless XFOIL session for a single alpha; parse stdout.

        Returns (cl, cd, cm) or None if the point didn't converge.
        """
        cmds = ["PLOP", "G F", ""]          # headless (no X11)
        cmds += list(geom_cmds)             # NACA xxxx + PANE, or LOAD + PANE
        cmds += ["OPER"]
        cmds += [f"VISC {reynolds:.1f}"]
        cmds += ["VPAR", f"N {self.ncrit:.3f}", ""]   # Ncrit via VPAR sub-menu
        cmds += [f"ITER {self.iters}"]
        cmds += [f"ALFA {alpha:.4f}"]
        cmds += ["", "QUIT"]
        stdin = "\n".join(cmds) + "\n"

        try:
            proc = subprocess.run(
                [self._resolved], input=stdin, text=True,
                capture_output=True, timeout=self.timeout, cwd=_tmpdir())
        except subprocess.TimeoutExpired:
            return None

        return _parse_single(proc.stdout or "")


def _parse_single(stdout: str):
    """Parse one single-alpha XFOIL session's stdout -> (cl, cd, cm) or None.

    XFOIL prints, per iteration, a pair:
        a =  5.000      CL =  0.5500
       Cm = -0.0012     CD =  0.00800   =>  ...
    The LAST such pair in the output is the converged result. If XFOIL failed
    to converge it prints 'VISCAL:  Convergence failed' and the last CL is
    unreliable, so we treat a visible convergence-failure as non-converged.
    """
    import re
    if "Convergence failed" in stdout:
        return None
    cl_matches = re.findall(r"a\s*=\s*(-?\d+\.\d+)\s+CL\s*=\s*(-?\d+\.\d+)",
                            stdout)
    cd_matches = re.findall(r"Cm\s*=\s*(-?\d+\.\d+)\s+CD\s*=\s*(-?\d+\.\d+)",
                            stdout)
    if not cl_matches or not cd_matches:
        return None
    cl = float(cl_matches[-1][1])
    cm = float(cd_matches[-1][0])
    cd = float(cd_matches[-1][1])
    # XFOIL occasionally emits CD <= 0 on a non-physical non-converged exit
    if cd <= 0:
        return None
    return cl, cd, cm


def _parse_stdout(stdout: str):
    """Fallback: recover converged points from XFOIL's console output.

    XFOIL prints each converged point as a pair of lines:
        a =  5.000      CL =  0.5500
       Cm = -0.0012     CD =  0.00800   =>  ...
    We pair consecutive 'a =/CL =' and 'Cm =/CD =' lines. Keeps only the
    LAST occurrence per alpha (the converged value after iteration).
    """
    import re
    a_cl = re.compile(r"a\s*=\s*(-?\d+\.\d+)\s+CL\s*=\s*(-?\d+\.\d+)")
    cm_cd = re.compile(r"Cm\s*=\s*(-?\d+\.\d+)\s+CD\s*=\s*(-?\d+\.\d+)")
    points = {}   # alpha -> (cl, cd, cm)
    lines = stdout.splitlines()
    pending = None
    for ln in lines:
        m1 = a_cl.search(ln)
        if m1:
            pending = (float(m1.group(1)), float(m1.group(2)))
            continue
        m2 = cm_cd.search(ln)
        if m2 and pending is not None:
            a, cl = pending
            cm, cd = float(m2.group(1)), float(m2.group(2))
            points[round(a, 3)] = (cl, cd, cm)
            pending = None
    if not points:
        return (np.array([]), np.array([]), np.array([]), np.array([]))
    a = np.array(sorted(points))
    cl = np.array([points[x][0] for x in a])
    cd = np.array([points[x][1] for x in a])
    cm = np.array([points[x][2] for x in a])
    return a, cl, cd, cm


def _parse_polar_file(path: str):
    """Parse an XFOIL PACC polar file -> (alpha, cl, cd, cm) arrays.

    The file has a ~12-line header; the data block columns are:
        alpha  CL  CD  CDp  CM  Top_Xtr  Bot_Xtr
    We take columns 0,1,2,4.
    """
    a, cl, cd, cm = [], [], [], []
    if not os.path.isfile(path):
        return (np.array([]), np.array([]), np.array([]), np.array([]))
    with open(path) as f:
        lines = f.readlines()
    data_started = False
    for ln in lines:
        if "-----" in ln:          # dashed rule precedes the data block
            data_started = True
            continue
        if not data_started:
            continue
        parts = ln.split()
        if len(parts) < 5:
            continue
        try:
            vals = [float(p) for p in parts[:5]]
        except ValueError:
            continue
        a.append(vals[0]); cl.append(vals[1]); cd.append(vals[2]); cm.append(vals[4])
    return (np.array(a), np.array(cl), np.array(cd), np.array(cm))


# --------------------------------------------------------------------------
# Mock analytic solver (pipeline development without XFOIL)
# --------------------------------------------------------------------------
class MockSolver(BaseSolver):
    """Analytic stand-in with the XfoilSolver interface. NOT PHYSICS.

    Purpose: let D1-D4 be built and unit-tested where XFOIL isn't installed,
    and let CI exercise the full pipeline deterministically. Produces a
    plausible-SHAPED polar (linear lift region, soft stall, quadratic drag
    bucket) driven by crude camber/thickness readouts of the geometry, so
    different airfoils give different — but meaningless — numbers.

    Do NOT draw any aerodynamic conclusion from MockSolver output.
    """

    def __init__(self, cl_alpha_per_deg: float = 0.11, stall_deg: float = 14.0,
                 cd0: float = 0.006, k_induced: float = 0.012):
        self.cl_alpha = cl_alpha_per_deg
        self.stall = stall_deg
        self.cd0 = cd0
        self.k = k_induced

    def run_coords(self, coords, reynolds, alphas, name="coords") -> Polar:
        coords = np.asarray(coords, float)
        camber, thick = _camber_thickness(coords)
        return self._model(reynolds, np.asarray(alphas, float),
                           camber, thick, source=f"MOCK {name}")

    def run_naca(self, code, reynolds, alphas) -> Polar:
        # read camber/thickness straight off the 4-digit code, no generator needed
        m = int(code[0]) / 100.0
        t = int(code[2:]) / 100.0
        return self._model(reynolds, np.asarray(alphas, float), m, t,
                           source=f"MOCK NACA{code}")

    def _model(self, reynolds, alphas, camber, thick, source) -> Polar:
        a0 = -camber * 40.0                      # zero-lift angle shifts with camber
        cl_lin = self.cl_alpha * (alphas - a0)
        # soft stall via tanh envelope
        env = np.where(np.abs(alphas) < self.stall, 1.0,
                       np.exp(-(np.abs(alphas) - self.stall) / 3.0))
        cl = cl_lin * env
        cd = self.cd0 * (1 + 4 * thick) + self.k * cl**2 + \
            0.02 * np.clip(np.abs(alphas) - self.stall, 0, None)**2
        cm = -0.1 * camber - 0.01 * alphas * 0.0  # crude, roughly constant
        cm = np.full_like(alphas, -0.1 * camber)
        return Polar(alpha=alphas, cl=cl, cd=cd, cm=cm, reynolds=reynolds,
                     source=source, n_requested=len(alphas),
                     meta={"MOCK": True, "camber": camber, "thick": thick})


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------
def _camber_thickness(coords: np.ndarray):
    """Very crude camber & thickness readout from a coordinate loop.

    Good enough to make MockSolver differentiate airfoils; not used by XFOIL.
    """
    x = coords[:, 0]
    y = coords[:, 1]
    # normalise chord to 1
    c = x.max() - x.min()
    if c <= 0:
        return 0.0, 0.1
    xs = (x - x.min()) / c
    ys = y / c
    # sample thickness/camber at a few chord stations by nearest points
    cambers, thicks = [], []
    for xc in np.linspace(0.1, 0.9, 9):
        near = np.abs(xs - xc) < 0.05
        if near.sum() >= 2:
            yy = ys[near]
            thicks.append(yy.max() - yy.min())
            cambers.append((yy.max() + yy.min()) / 2)
    camber = float(np.mean(cambers)) if cambers else 0.0
    thick = float(np.max(thicks)) if thicks else 0.1
    return camber, thick


def _tmpdir() -> str:
    d = os.environ.get("FINOPT_TMP", os.path.join(tempfile.gettempdir(), "finopt"))
    os.makedirs(d, exist_ok=True)
    return d


def _quiet_remove(path: str):
    try:
        os.remove(path)
    except OSError:
        pass


def get_solver(prefer_xfoil: bool = True, xfoil_path: str = "xfoil",
               **kw) -> BaseSolver:
    """Return XfoilSolver if available, else MockSolver with a warning.

    This is the single place the rest of the code asks for a solver, so
    'real vs mock' is decided once.
    """
    if prefer_xfoil:
        xs = XfoilSolver(xfoil_path=xfoil_path, **{k: v for k, v in kw.items()
                         if k in ("iters", "ncrit", "timeout", "n_panel")})
        if xs.available:
            return xs
        warnings.warn("XFOIL not found; falling back to MockSolver "
                      "(placeholder physics — dev/CI only).")
    return MockSolver()
