# finopt — family-agnostic fin airfoil optimizer

Builds toward a **true optimizer** (not a database sweep) over airfoil shape
for the solar-car fin, on the work-weighted race-time proxy objective, with
clean seams for the components not yet accessible (Raytracer, real wind data,
3D CFD). See `fin_optimizer_roadmap.md` for the full deliverable ladder.

## Status: D0 complete (solver + known-answer check)

```
finopt/
  solver.py     XfoilSolver (real) + MockSolver (dev) behind one interface
  geometry.py   NACA-4 generator, .dat load/write (Eppler/CH/UIUC seed for D1)
tests/
  test_d0_naca0012.py   NACA 0012 @ Re=1e6 known-answer check
run_d0.py       one-command runner for your laptop
```

## Run the D0 check

On your laptop (XFOIL installed and on PATH):

```bash
python run_d0.py              # prints PASS/FAIL vs reference bands
python run_d0.py --plot       # also saves outputs/d0_naca0012.png
XFOIL=/usr/local/bin/xfoil python run_d0.py   # if not on PATH
```

Without XFOIL (e.g. a CAEN box) it runs the MockSolver wiring check instead
and tells you so — real aero numbers require the XFOIL binary.

## The one interface everything uses

```python
from finopt import get_solver, naca4_coords
import numpy as np

solver = get_solver(xfoil_path="xfoil")          # XFOIL if present, else mock
polar  = solver.run_naca("0012", 1e6, np.arange(-6, 12, 1.0))
polar2 = solver.run_coords(coords, 1e6, alphas)  # any (N,2) airfoil -> same Polar
print(polar.cl_at(5.0), polar.cd_at(5.0), polar.cl_slope_per_deg())
```

`run_coords` is the family-agnostic path: feed NACA, Eppler, CH, or any UIUC
`.dat` and get back the same `Polar`. That uniform representation is what the
teammate's XFOIL sweep has at the solver level and what D1 makes explicit and
validated in the pipeline.

## Key knob to watch: `ncrit`

`XfoilSolver(ncrit=...)` sets the transition parameter. 9 = clean tunnel;
the real roadgoing fin sees rougher flow, so **lower Ncrit (~4–7) is more
honest**, and at the fin's low Reynolds number the airfoil ranking can move
with this setting. Pin it identically across every airfoil in a comparison.

## Next: D1

Harden the `.dat` loaders (Eppler/CH/UIUC, both Selig and Lednicer orderings),
add the family-agnostic validation check, then D2 (the work-weighted objective).
