"""
finopt.geometry — airfoil coordinate generation and loading.

D0 needs only `naca4_coords` (to feed the coordinate path and as a D1 seed).
D1 will add `.dat` loaders (Eppler/CH/UIUC) that return the SAME (N,2)
array format, so the solver never knows which family it came from — that
uniform representation is the whole point of the family-agnostic front end.

Convention: coordinates returned as an (N,2) array of (x, y), ordered
XFOIL-style: trailing edge -> upper surface -> leading edge -> lower
surface -> trailing edge, with chord from x=0 to x=1.
"""

from __future__ import annotations

import numpy as np


def naca4_coords(code: str, n: int = 160, closed_te: bool = False) -> np.ndarray:
    """Generate NACA 4-digit airfoil coordinates.

    Parameters
    ----------
    code : 4-char string, e.g. "0012", "2412", "3211".
           digits = (m*100, p*10, tt) : m=max camber %, p=camber position
           /10, tt=thickness %.
    n    : number of points per surface (cosine-spaced).
    closed_te : if True use the closed-trailing-edge thickness constant
                (-0.1036) instead of the classic open-TE (-0.1015). XFOIL
                re-panels anyway, but Eppler/CH .dat files are often sharp,
                so matching TE closure matters for apples-to-apples.

    Returns
    -------
    (2n-1, 2) array of (x, y), TE -> upper -> LE -> lower -> TE.
    """
    if len(code) != 4 or not code.isdigit():
        raise ValueError(f"NACA 4-digit code must be 4 digits, got {code!r}")
    m = int(code[0]) / 100.0
    p = int(code[1]) / 10.0
    t = int(code[2:]) / 100.0

    # cosine spacing clusters points at LE and TE where curvature is high
    beta = np.linspace(0.0, np.pi, n)
    x = (1 - np.cos(beta)) / 2.0

    a4 = -0.1036 if closed_te else -0.1015
    yt = 5 * t * (0.2969 * np.sqrt(x) - 0.1260 * x - 0.3516 * x**2
                  + 0.2843 * x**3 + a4 * x**4)

    if m > 0 and p > 0:
        yc = np.where(x < p,
                      m / p**2 * (2 * p * x - x**2),
                      m / (1 - p)**2 * ((1 - 2 * p) + 2 * p * x - x**2))
        dyc = np.where(x < p,
                       2 * m / p**2 * (p - x),
                       2 * m / (1 - p)**2 * (p - x))
        theta = np.arctan(dyc)
    else:
        yc = np.zeros_like(x)
        theta = np.zeros_like(x)

    xu = x - yt * np.sin(theta)
    yu = yc + yt * np.cos(theta)
    xl = x + yt * np.sin(theta)
    yl = yc - yt * np.cos(theta)

    # assemble TE -> upper -> LE -> lower -> TE (drop duplicated LE point)
    x_coords = np.concatenate([xu[::-1], xl[1:]])
    y_coords = np.concatenate([yu[::-1], yl[1:]])
    return np.column_stack([x_coords, y_coords])


def load_dat(path: str) -> np.ndarray:
    """Load a Selig/UIUC-format .dat airfoil file -> (N,2) coords.

    Handles the common header line (airfoil name) and both Selig ordering
    (TE->upper->LE->lower->TE, one block) and Lednicer ordering (two blocks
    with point counts on line 2). D1 will harden this; here it covers the
    Selig format the UIUC database ships Eppler/CH airfoils in.
    """
    rows = []
    with open(path) as f:
        lines = f.readlines()
    # detect Lednicer: line 2 is two numbers (point counts), both > 1
    header_skipped = False
    for i, ln in enumerate(lines):
        parts = ln.split()
        if len(parts) != 2:
            continue
        try:
            a, b = float(parts[0]), float(parts[1])
        except ValueError:
            header_skipped = True   # a name line
            continue
        # Lednicer count line looks like "61. 61." (both >> 1, integral)
        if i <= 1 and a > 1.5 and b > 1.5 and a == int(a) and b == int(b):
            continue
        rows.append((a, b))
    coords = np.array(rows, float)
    if coords.ndim != 2 or coords.shape[0] < 10:
        raise ValueError(f"Could not parse enough coordinates from {path!r}")
    return coords


def write_dat(coords: np.ndarray, path: str, name: str = "airfoil"):
    """Write coords to a Selig .dat file (for inspection / feeding XFOIL)."""
    with open(path, "w") as f:
        f.write(f"{name}\n")
        for x, y in coords:
            f.write(f"{x:.6f} {y:.6f}\n")
